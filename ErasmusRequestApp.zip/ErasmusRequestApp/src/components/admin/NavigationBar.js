import React from 'react';
import {Nav, Navbar} from "react-bootstrap";
import {Link} from "react-router-dom";
import { withRouter } from '../../withRouter.js';
import EventBus from "../../common/EventBus";
import AuthService from "../../services/authService";

class NavigationBar extends React.Component {
    constructor(props){
        super(props);
        this.NavRegister=this.NavRegister.bind(this);
        this.NavModify=this.NavModify.bind(this);
        this.NavAddErasmusCommittee=this.NavAddErasmusCommittee.bind(this);
        this.NavLogout=this.NavLogout.bind(this);
        this.logOut = this.logOut.bind(this);

    }
    componentDidMount() {
        EventBus.on("logout", () => {
            this.logOut();
        });
    }
    componentWillUnmount() {
        EventBus.remove("logout");
    }
    logOut() {
        AuthService.logout();

    }

    NavAddErasmusCommittee()
    {
        this.props.navigate('/admin/erasmuscommittee/add')
    }

    NavModify()
    {
        this.props.navigate('/admin/users/modify')
    }
    NavRegister()
    {
        this.props.navigate('/admin/users/register')
    }
    NavLogout(){
        AuthService.logout();
        this.props.navigate('/login')
    }
    render(){
        return (
            <Navbar bg="dark" variant="dark">


                <Navbar.Brand >&emsp;&emsp; ErasmusRequest</Navbar.Brand>
                <Nav >
                    <Nav.Link onClick={this.NavRegister} ><span className="icon-nav" data-symbol="&#xf090;" />&ensp; Register</Nav.Link>
                    <Nav.Link onClick={this.NavModify} ><span className="icon-nav" data-symbol="&#xf021;" />&ensp; Modify</Nav.Link>
                    <Nav.Link onClick={this.NavAddErasmusCommittee} ><span className="icon-nav" data-symbol="&#xf067;" />&ensp; Add Erasmus Committee</Nav.Link>
                    <Nav.Link  style={{ position:'fixed',top:'10px', right:'30px'}} onClick={this.NavLogout}>Logout</Nav.Link>
                    <Nav.Link style={{ position:'fixed',top:'6px', right:'130px'}}><span className="icon-nav" data-symbol="&#xf007;"/>&ensp;{AuthService.getCurrentUser().username} </Nav.Link>
                </Nav>




            </Navbar>
        );
    }
}

export default withRouter(NavigationBar);