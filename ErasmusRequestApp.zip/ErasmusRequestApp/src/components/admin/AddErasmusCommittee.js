import React from "react";
import {Form} from "react-bootstrap";
import axios from "axios";
import MyToast from "../myToast";
import AuthService from "../../services/authService";

class AddErasmusCommittee extends React.Component{
    constructor(props){
        super(props);
        this.state={
            name:'',
            email:'',
            field:'Job',
            errors: { name: '', email:'', field:'' }
        }

        this.changeNameHandler=this.changeNameHandler.bind(this);
        this.changeEmailHandler=this.changeEmailHandler.bind(this);
        this.changeFieldHandler=this.changeFieldHandler.bind(this);
        this.addErasmusCommittee=this.addErasmusCommittee.bind(this);
        this.state.showSuccess =false;
    }
    initialState={
        name:'',
        email:'',
        field:'Job',
    }
    returnErasmusCommittee=()=>{
        return {
            name: this.state.name,
            email: this.state.email,
            field: this.state.field
        };
    }

    returnErrors=()=>{
        return { name: '', email:'', field:'' };
    }
    handleValidation = (ErasmusCommittee,errors) => {

        if (!ErasmusCommittee.name) {
            errors.name = 'Name is required';
        }

        if (!ErasmusCommittee.email) {
            errors.email = 'Email is required';
        }


        // Rest of validation conditions go here...

        this.setState({ errors });
    }
    changeNameHandler=(event)=>{
        this.handleValidation(this.returnErasmusCommittee(),this.returnErrors());
        this.setState({name:event.target.value});

    }

    changeEmailHandler=(event)=>{
        this.handleValidation(this.returnErasmusCommittee(),this.returnErrors());
        this.setState({email:event.target.value});

    }

    changeFieldHandler=(event)=>{
        this.handleValidation(this.returnErasmusCommittee(),this.returnErrors());
        this.setState({field:event.target.value});

    }

    addErasmusCommittee=(e)=>{
        e.preventDefault();
        let ErasmusCommittee= this.returnErasmusCommittee();

        let errors = this.returnErrors();

        this.handleValidation(ErasmusCommittee,errors);

        if(ErasmusCommittee.name&&ErasmusCommittee.email){
            console.log('Erasmus Committee=>' + JSON.stringify(ErasmusCommittee));
            axios.post("/admin/ErasmusCommittee/add",ErasmusCommittee, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
                .then(response =>{
                    if(response.data!=null){
                        this.setState({"showSuccess":true});
                        this.setState(this.initialState);
                        setTimeout(()=> this.setState({"showSuccess":false}),4000);

                    }else{
                        this.setState({"showSuccess":false});
                    }

                })
                .catch((error)=>{
                    alert("Error!")
                });
        }

    }
    render() {
        const { errors } = this.state;
        const {name,
            email,
            field} = this.state;
        return (
            <div className="outer" style={{marginTop:10}}>
                <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                    <MyToast children={{showSuccess:this.state.showSuccess,messageSuccess:"Erasmus Committee Added Successfully!"}}/>
                </div>
                <div className="inner container-fluid bg-dark" style={{background:"#272B30"}}>
                    <div className=' col-md-6 offset-md-3 text-light'>
                        <span className="login100-form-title text-light m-b-23">
						Add ErasmusCommittee
					    </span>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Email</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="email" value={email} onChange={this.changeEmailHandler} name="email" placeholder="Type the organization's email"/>
                            <span className="focus-input100" />
                            {errors.email !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.email}</span>}

                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Name</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="text" name="name" value={name} onChange={this.changeNameHandler} placeholder="Type the organization's name"/>
                            <span className="focus-input100" />
                            {errors.name !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.name}</span>}

                        </div>


                        <div  >
                            <span className="label-input100 text-light ">Field</span>
                            <Form.Select onChange={this.changeFieldHandler} defaultValue="Role" className="input100" style={{height:40}}>
                                <option className="input100" value="Teacher">Teacher</option>
                                <option className="input100" value="Student">Student</option>
                            </Form.Select>
                        </div>


                        <div className="container-login100-form-btn">
                            <div className="wrap-login100-form-btn">
                                <div className="login100-form-bgbtn"/>
                                <button type="submit" onClick={this.addErasmusCommittee} className="login100-form-btn">
                                    ADD
                                </button>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        );
    }

}

export default AddErasmusCommittee;