import React from "react";
import {Form} from 'react-bootstrap'
import axios from "axios";
import MyToast from "../myToast";
import MyToastFailure from "../MyToastFailure";
import {withRouter} from "../../withRouter";
import AuthService from "../../services/authService";

class RegisterPage extends React.Component{
    constructor(props){
        super(props);
        this.state={
            firstName:'',
            surname:'',
            email:'',
            it:'',
            password:'',
            role:'ADMIN',
            errors: { firstName: '', surname:'', email:'', it:'', password:'', role:'' }
        }

        this.changeFirstNameHandler=this.changeFirstNameHandler.bind(this);
        this.changeSurnameHandler=this.changeSurnameHandler.bind(this);
        this.changeEmailHandler=this.changeEmailHandler.bind(this);
        this.changeItHandler=this.changeItHandler.bind(this);
        this.changePasswordHandler=this.changePasswordHandler.bind(this);
        this.changeRoleHandler=this.changeRoleHandler.bind(this);
        this.saveUser=this.saveUser.bind(this);
        this.state.showSuccess =false;
        this.state.showFailure = false;

    }

    initialState ={
            firstName:'',
            surname:'',
            email:'',
            it:'',
            password:'',
            role:'ADMIN'
    }
    returnUser=()=>{
        return {
            it: this.state.it,
            email: this.state.email,
            firstName: this.state.firstName,
            surname: this.state.surname,
            password: this.state.password,
            role: this.state.role
        };
}

    componentDidMount() {
        const userIt= this.props.params.it;
        if(userIt){
            this.findUserByIt(userIt);
        }
    }
    findUserByIt = (userIt)=>{
        axios.get("/admin/users/modify/"+userIt, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response =>{
                if(response!=null){
                    this.setState({
                        it:response.data.it,
                        email: response.data.email,
                        firstName: response.data.firstName,
                        surname: response.data.surname,
                        password: response.data.password,
                        role: response.data.role
                    });
                }
            }).catch((error) =>{
            console.log("Error: "+error);
        });
    }
    returnErrors=()=>{
            return { firstName: '', surname:'', email:'', it:'', password:'', role:'' };
    }
    changeFirstNameHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnUser().firstName) {
            this.returnErrors().firstName = 'First Name is required';
        }
        this.setState({firstName:event.target.value});
        this.setState({ errors });

    }

    changeSurnameHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnUser().surname) {
            this.returnErrors.surname = 'Surname is required';
        }
        this.setState({surname:event.target.value});
        this.setState({ errors });
    }

    changeEmailHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnUser().email) {
            this.returnErrors().email = 'Email is required';
        }
        this.setState({email:event.target.value});
        this.setState({ errors });

    }

    changeItHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnUser().it) {
            this.returnErrors().it = 'It is required';
        }

        this.setState({it:event.target.value});
        this.setState({ errors });

    }

    changePasswordHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnUser().password) {
            this.returnErrors().password = 'Password is required';
        }
        this.setState({password:event.target.value});
        this.setState({ errors });

    }

    changeRoleHandler=(event)=>{

        this.setState({role:event.target.value});

    }
    handleValidation = (user,errors) => {
       // let user={it: this.state.it,email: this.state.email,firstName: this.state.firstName, lastName: this.state.lastName,   password: this.state.password, role: this.state.role};

        //let errors = { firstName: '', lastName:'', email:'', it:'', password:'', role:'' };

        if (!user.it) {
            errors.it = 'It is required';
        }

        if (!user.firstName) {
            errors.firstName = 'First Name is required';
        }
        if (!user.surname) {
            errors.surname = 'Surname is required';
        }
        if (!user.email) {
            errors.email = 'Email is required';
        }
        if (!user.password) {
            errors.password = 'Password is required';
        }


        // Rest of validation conditions go here...

        this.setState({ errors });
    }
    userList = () => {
        return this.props.navigate("/admin/users/modify");
    };

    updateUser =(e)=>{
        e.preventDefault();
        let user= this.returnUser();

        let errors = this.returnErrors();

        this.handleValidation(user,errors);

        // Rest of validation conditions go here...

        this.setState({ errors });
        if(user.password&&user.firstName&&user.surname&&user.it&&user.email&&user.role){
            //console.log('Student=>' + JSON.stringify(user));
            axios.put("/admin/users/modify/"+user.it,user, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
                .then(response =>{
                    if(response.status===406) throw new Error(response.status);
                    else if(response.data!=null){
                        this.setState({"showSuccess":true,"method":"put"});
                        this.setState(this.initialState);
                        setTimeout(()=> this.setState({"showSuccess":false}),3000);
                        setTimeout(()=> this.userList(),1000);


                    }else{
                        this.setState({"showSuccess":false});
                    }

                })
                .catch((error)=>{
                    this.setState({"showFailure":true});
                    setTimeout(()=> this.setState({"showFailure":false}),4000);
                });
        }
    }

    saveUser=(e)=>{
        e.preventDefault();
        let user= this.returnUser();

        let errors = this.returnErrors();

        this.handleValidation(user,errors);

        // Rest of validation conditions go here...

        this.setState({ errors });
        if(user.password&&user.firstName&&user.surname&&user.it&&user.email&&user.role){
            //console.log('Student=>' + JSON.stringify(user));
            axios.post("/admin/users/register",user, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
                .then(response =>{
                    if(response.status===406) throw new Error(response.status);
                    else if(response.data!=null){
                        this.setState({"showSuccess":true,"method":"post"});
                        this.setState(this.initialState);
                        setTimeout(()=> this.setState({"showSuccess":false}),4000);

                    }else{
                        this.setState({"showSuccess":false});
                    }

                })
                .catch((error)=>{
                    this.setState({"showFailure":true});
                    setTimeout(()=> this.setState({"showFailure":false}),4000);
                });
        }

    }



    render() {
        const { errors } = this.state;
        const {firstName,
            surname,
            email,
            it,
            password,
            role} = this.state;


        return (

            <div className="outer">
                <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                    <MyToast children={{showSuccess:this.state.showSuccess}} message={this.state.method ==="put" ? "User Updated Successfully!" : "User Added Successfully!"}/>
                </div>
                <div style={{display:this.state.showFailure ? "block" :"none"}}>
                    <MyToastFailure children={{showFailure:this.state.showFailure,messageFailure:"User Already Exists!"}}/>
                </div>
                <div className="inner container-fluid bg-dark" >
                    <div className=' col-md-6 offset-md-3 text-light'>
                        <span className="login100-form-title text-light ">
                            {this.props.location.pathname ==="/admin/users/register" ? "Create New User" : "Modify User"}

					    </span>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>IT</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} autoComplete={"off"} type="text" name="it" value={it} onChange={this.changeItHandler} placeholder="Type your it"/>
                            <span className="focus-input100" />
                            {errors.it !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.it}</span>}

                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>First Name</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} autoComplete={"off"} type="text" name="firstName" value={firstName} onChange={this.changeFirstNameHandler} placeholder="Type your first name"/>
                            <span className="focus-input100" />
                            {errors.firstName !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.firstName}</span>}
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Surname</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} autoComplete="off" type="text" name="Surname" value={lastName} onChange={this.changeSurnameHandler} placeholder="Type your Surname"/>
                            <span className="focus-input100" />
                            {errors.surname !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.surname}</span>}
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Password</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} autoComplete="off" type="text" name="password" value={password} onChange={this.changePasswordHandler} placeholder="Type your password"/>
                            <span className="focus-input100" />
                            {errors.password !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.password}</span>}
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Email</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} autoComplete="off" type="email" name="email" value={email} onChange={this.changeEmailHandler} placeholder="Type your email"/>
                            <span className="focus-input100" />
                            {errors.email !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.email}</span>}
                        </div>

                        <div  >
                            <span className="label-input100 text-light ">Role</span>
                            <Form.Select onChange={this.changeRoleHandler} value={role} className="input100" style={{height:40}}>
                                <option className="input100" value="ADMIN">Admin</option>
                                <option className="input100" value="STUDENT">Student</option>
                                <option className="input100" value="TEACHER">Teacher</option>
                            </Form.Select>
                            {errors.role !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.role}</span>}
                        </div>


                        <div className="container-login100-form-btn">
                            <div className={this.props.location.pathname ==="/admin/users/register" ? "wrap-login100-form-btn" : "wrap-login100-form-btn-update"}>
                                <div className={this.props.location.pathname ==="/admin/users/register" ? "login100-form-bgbtn" : "login100-form-bgbtn-update"}/>
                                <button type="submit" onClick={this.props.location.pathname ==="/admin/users/register" ?  this.saveUser : this.updateUser} className="login100-form-btn">
                                    {this.props.location.pathname ==="/admin/users/register" ? "REGISTER" : "UPDATE"}
                                </button>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        );
    }

}

export default withRouter(RegisterPage);