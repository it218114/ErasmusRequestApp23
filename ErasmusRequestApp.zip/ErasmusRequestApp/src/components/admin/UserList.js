import React from "react";

import {Button, ButtonGroup, Card, Table} from 'react-bootstrap';

import axios from "axios";
import MyToast from "../myToast";
import { withRouter } from '../../withRouter.js';
import AuthService from '../../services/authService';

class UserList extends React.Component{

    constructor(props) {
        super(props);
        this.state={
            users :[]
        };
        this.state.showSuccess =false;

    }
    componentDidMount() {
         this.findAllUsers();
    }
    refresh = () => {
        window.location.reload();
    };
    deleteUser = (userIt)=>{
        axios.delete("modify/"+userIt, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response=>{
                if(response.data!=null){
                    this.setState({"showSuccess":true});
                    setTimeout(()=> this.setState({"showSuccess":false}),4000);
                    this.state({
                       users: this.state.users.filter(user => user.it !==userIt)
                    });
                    setTimeout(()=> this.refresh(),1000);
                }else{
                    this.setState({"showSuccess":false});
                }
            });
    };
    NavEdit=(user)=>
    {
        this.props.navigate('/admin/users/modify/'+user.it)
    }

    findAllUsers(){

        axios.get("/admin/users", {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response => response.data)
            .then((data)=>{
                this.setState({users:data});
            });
    }

    render() {
        return (
            <div>
                <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                    <MyToast children={{showSuccess:this.state.showSuccess,messageSuccess:"User Deleted Successfully!"}}/>
                </div>

                <Card className={"border border-dark bg-dark text-light"} style={{marginTop:10,borderRadius:15}}>
                    <Card.Header className="login100-form-title text-light">Users List</Card.Header>
                    <Card.Body>
                        <Table bordered hover stripped variant="dark" >
                            <thead>
                            <tr>
                                <th>it</th>
                                <th>First Name</th>
                                <th>Surname</th>
                                <th>Password</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Actions</th>
                            </tr>
                            </thead>
                            <tbody>

                                {this.state.users.length === 0 ?
                                    <tr>
                                        <td colSpan="7">No Users In the System.</td>
                                    </tr> :
                                    this.state.users.map((user)=>(
                                        <tr key={user.it}>
                                            <td>{user.it}</td>
                                            <td>{user.firstName}</td>
                                            <td>{user.surname}</td>
                                            <td>{user.password}</td>
                                            <td>{user.email}</td>
                                            <td>{user.role}</td>
                                            <td>
                                                <ButtonGroup>
                                                    <Button size="sm" variant="outline-primary" onClick={this.NavEdit.bind(this,user)}><span className="normal-icon" data-symbol="&#xf044;" /></Button>
                                                    <Button size="sm" variant="outline-danger" onClick={this.deleteUser.bind(this,user.it)}><span className="normal-icon" data-symbol="&#xf1f8;" /></Button>
                                                </ButtonGroup>
                                            </td>
                                        </tr>
                                    ))
                                }

                            </tbody>
                        </Table>

                    </Card.Body>
                </Card>
            </div>
        );
    }

}

export default withRouter(UserList);