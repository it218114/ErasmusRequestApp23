import React from 'react';
import {Nav, Navbar} from "react-bootstrap";
import {Link} from "react-router-dom";

import { withRouter } from '../../withRouter.js';
import AuthService from "../../services/authService";

class NavBarTeacher extends React.Component {
    constructor(props){
        super(props);
        this.NavRequests=this.NavRequests.bind(this);
        this.NavLogout=this.NavLogout.bind(this);

    }
    NavRequests()
    {
        this.props.navigate('/requests/sendto/')
    }
    NavLogout(){
        AuthService.logout();
        this.props.navigate('/login')
    }

    render(){
        return (
            <Navbar bg="dark" variant="dark">


                <Navbar.Brand >&emsp;&emsp; ErasmusRequest</Navbar.Brand>
                <Nav >
                    <Nav.Link onClick={this.NavRequests}><span className="icon-nav" data-symbol="&#xf01c;" />&ensp; Requests</Nav.Link>
                    <Nav.Link style={{ position:'fixed',top:'10px', right:'30px'}} onClick={this.NavLogout}>Logout</Nav.Link>
                    <Nav.Link style={{ position:'fixed',top:'6px', right:'130px'}}><span className="icon-nav" data-symbol="&#xf007;"/>&ensp;{AuthService.getCurrentUser().username} </Nav.Link>
                </Nav>




            </Navbar>
        );
    }
}

export default withRouter(NavBarTeacher);