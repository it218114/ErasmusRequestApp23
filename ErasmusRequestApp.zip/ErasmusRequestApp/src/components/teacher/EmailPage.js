import React from "react";
import {Form} from "react-bootstrap";
import axios from "axios";
import MyToast from "../myToast";
import InfoToast from "../infoToast";
import MyToastFailure from "../MyToastFailure";
import {withRouter} from "../../withRouter";
import AuthService from "../../services/authService";

class EmailPage extends React.Component{
    constructor(props){
        super(props);
        this.state={
            to:'',
            from:'',
            subject:'',
            body:'',
            emails:[],
            firstElement:[],
            errors: { to: '', from:'', subject:'', body:''}
        }

        this.changeToHandler=this.changeToHandler.bind(this);
        this.changeFromHandler=this.changeFromHandler.bind(this);
        this.changeSubjectHandler=this.changeSubjectHandler.bind(this);
        this.changeBodyHandler=this.changeBodyHandler.bind(this);
        this.sendEmail=this.sendEmail.bind(this);
        this.state.showSuccess =false;
        this.state.showFailure = false;

    }

    initialState ={
        to:'',
        from:'',
        subject:'',
        body:''
    }
    componentDidMount() {
        const userIt= this.props.params.it;
        if(userIt){
            this.findReferralByCreatedBy(userIt);
        }
    }
    findReferralByCreatedBy = (userIt)=>{
        axios.get("/requests/approved/"+userIt, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response =>{
                if(response!=null){
                    this.setState({emails:response.data});
                    this.setState({firstElement:this.state.emails[0]})

                }
            }).catch((error) =>{
            console.log("Error: "+error);
        });
    }
    returnEmail=()=>{
        return {
            to: this.state.to,
            from: this.state.from,
            body: this.state.body,
            subject: this.state.subject
        };
    }

    returnErrors=()=>{
        return { to: '', from:'', subject:'', body:''};
    }
    changeToHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnEmail().to) {
            this.returnErrors().to = 'Receiver is required';
        }
        this.setState({to:event.target.value});
        this.setState({ errors });

    }

    changeFromHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnEmail().from) {
            this.returnErrors().from = 'Sender is required';
        }
        this.setState({from:event.target.value});
        this.setState({ errors });
    }

    changeSubjectHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnEmail().subject) {
            this.returnErrors().subject = 'Subject is required';
        }
        this.setState({subject:event.target.value});
        this.setState({ errors });

    }

    changeBodyHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnEmail().body) {
            this.returnErrors().body = 'Body is required';
        }

        this.setState({body:event.target.value});
        this.setState({ errors });

    }


    handleValidation = (email,errors) => {
        // let user={it: this.state.it,email: this.state.email,firstName: this.state.firstName, lastName: this.state.lastName,   password: this.state.password, role: this.state.role};

        //let errors = { firstName: '', lastName:'', email:'', it:'', password:'', role:'' };

        if (!email.to) {
            errors.to = 'Receiver email is required';
        }

        if (!email.from) {
            errors.from = 'Sender email is required';
        }
        if (!email.subject) {
            errors.subject = 'Subject is required';
        }
        if (!email.body) {
            errors.body = 'Body is required';
        }



        // Rest of validation conditions go here...

        this.setState({ errors });
    }
    getDataForApprovedReq=(e)=>{
        e.preventDefault();
    }

    updateRequest=(createdBy,status)=>{
        let request = { status: status};
        axios.put("/requests/sendTo/"+createdBy,request, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response =>{
                if(response.status===406) throw new Error(response.status);
                else if(response.data!=null){
                    console.log("Status updates")


                }

            })
            .catch((error)=>{
                console.log(error);
            });

    }

    sendEmail=(e)=>{
        e.preventDefault();
        let email= this.returnEmail();

        let errors = this.returnErrors();

        this.handleValidation(email,errors);
        console.log('Student=>' + JSON.stringify(email));
        if(email.to&&email.body&&email.subject){

            axios.post("/requests/approved",email, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
                .then(response =>{
                    if(response.status===404) throw new Error(response.status);
                    else if(response.data!=null){
                        this.setState({"showSuccess":true});
                        this.setState(this.initialState);
                        console.log(this.state.firstElement);
                        setTimeout(()=> this.setState({"showSuccess":false}),2000);
                        this.updateRequest.bind(this,this.state.firstElement.createdBy,"EMAILED");



                    }else{
                        this.setState({"showSuccess":false});
                    }

                })
                .catch((error)=>{
                    this.setState({"showFailure":true});
                    setTimeout(()=> this.setState({"showFailure":false}),4000);
                });
        }

    }
    render() {
        const { errors } = this.state;
        const {to,
            from,
            subject,
            body,
        firstElement} = this.state;
        return (
            <div className="outer" style={{marginTop:10}}>
                <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                    <MyToast children={{showSuccess:this.state.showSuccess,messageSuccess:"Email Send Successfully!"}}/>
                </div>
                <div style={{display:this.state.showFailure ? "block" :"none"}}>
                    <MyToastFailure children={{showFailure:this.state.showFailure,messageFailure:"Email Failed To send!"}}/>
                </div>
                <div>

                    <InfoToast id={firstElement.id} firstName={firstElement.firstName} surname={firstElement.surname} birthdate={firstElement.birthdate} grades={firstElement.sumgrade} field={firstElement.field}/>
                </div>

                <div className="inner container-fluid bg-dark" style={{background:"#272B30"}}>
                    <div className=' col-md-6 offset-md-3 text-light'>
                        <span className="login100-form-title text-light m-b-23">
						Create ErasmusRequest Email
					    </span>

                        <div  className="  m-b-23">
                            <span className="label-input100 text-light ">Receiver Email</span>
                            <Form.Select className="input100" defaultValue={"Select an email"} onChange={this.changeToHandler} style={{height:40}}>
                                <option disabled="true" className="input100" >Select an email</option>
                                {this.state.emails.map(email=>{
                                    console.log(email.email);
                                    if(email.email!=null) {
                                        return <option className="input100">{email.email}</option>
                                    }
                                }

                                )}

                            </Form.Select>
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Subject</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="text" name="subject" value={subject} onChange={this.changeSubjectHandler} placeholder="Type a subject"/>
                            <span className="focus-input100" />
                            {errors.subject !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.subject}</span>}
                        </div>
                        <Form.Group className="mb-3" controlId="exampleForm.ControlTextarea1">
                            <Form.Label className="label-input100 text-light ">Message</Form.Label>
                            <Form.Control className="input" value={body} onChange={this.changeBodyHandler} name="body" as="textarea" rows={7} />
                        </Form.Group>



                        <div className="container-login100-form-btn">
                            <div className="wrap-login100-form-btn">
                                <div className="login100-form-bgbtn"/>
                                <button type="submit" onClick={this.sendEmail} className="login100-form-btn">
                                    SEND
                                </button>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        );
    }

}

export default withRouter(EmailPage);