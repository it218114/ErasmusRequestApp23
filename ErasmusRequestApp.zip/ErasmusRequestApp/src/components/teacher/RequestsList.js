import React from "react";
import {Button, ButtonGroup, Card, Table} from "react-bootstrap";
import axios from "axios";
import MyToast from "../myToast";
import MyToastFailure from "../MyToastFailure";
import {withRouter} from "../../withRouter";
import AuthService from "../../services/authService";

class RequestsList extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            referrals :[]
        };
        this.state.showSuccess =false;
        this.state.showFailure = false;

    }
    componentDidMount() {
        this.findAllReferrals();
    }
    refresh = () => {
        window.location.reload();
    };
    NavEmail=(createdBy)=>{
        this.props.navigate("/requests/approved/"+createdBy);
    }

    updateRequest=(createdBy,status)=>{
        let request = { status: status};
        axios.put("/requests/sendTo/"+createdBy,request, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response =>{
                if(response.status===406) throw new Error(response.status);
                else if(response.data!=null){
                    this.setState({"showSuccess":true});
                    setTimeout(()=> this.setState({"showSuccess":false}),3000);
                    setTimeout(()=> this.refresh(),1000);


                }else{
                    this.setState({"showSuccess":false});
                }

            })
            .catch((error)=>{
                this.setState({"showFailure":true});
                setTimeout(()=> this.setState({"showFailure":false}),4000);
            });

    }
    findAllReferrals(){
        axios.get("/requests/sendTo", {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response => response.data)
            .then((data)=>{
                this.setState({referrals:data});
            });
    }
    render() {
        return (
            <div>
            <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                <MyToast children={{showSuccess:this.state.showSuccess}} message={"Request Updated Successfully!" }/>
            </div>
            <div style={{display:this.state.showFailure ? "block" :"none"}}>
                <MyToastFailure children={{showFailure:this.state.showFailure,messageFailure:"User Already Exists!"}}/>
            </div>
            <Card className={"border border-dark bg-dark text-light"} style={{marginTop:10,borderRadius:15}}>
                <Card.Header className="login100-form-title text-light">Requests</Card.Header>
                <Card.Body>
                    <Table bordered hover stripped variant="dark" >
                        <thead>
                        <tr>
                            <th>it</th>
                            <th>First Name</th>
                            <th>Surname</th>
                            <th>Birthdate</th>
                            <th>Summary Grade</th>
                            <th>Field</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>

                        {this.state.erasmusrequest.length === 0 ?
                            <tr>
                                <td colSpan="10">No erasmusrequest In the System.</td>
                            </tr> :
                            this.state.erasmusrequest.map((erasmusrequest)=>(
                                <tr key={erasmusrequest.id}>
                                    <td>{erasmusrequest.createdBy}</td>
                                    <td>{erasmusrequest.firstName}</td>
                                    <td>{erasmusrequest.surname}</td>
                                    <td>{erasmusrequest.birthdate}</td>
                                    {
                                    erasmusrequest.grades.split(',').map(grade =>
                                        <td>{grade}</td>
                                    )}

                                    <td>{erasmusrequest.field}</td>
                                    {erasmusrequest.status === "APPROVED" ?
                                        <td>
                                            <Button onClick={this.NavEmail.bind(this,erasmusrequest.createdBy)} size="sm" variant="outline-success" className={"input"}><span style={{paddingRight:5}} className="normal-icon" data-symbol="&#xf0e0;" />EMAIL</Button>
                                        </td>
                                        :erasmusrequest.status==="DECLINED" ?
                                            <td className={"input"} style={{color:"#8B0000"}}>
                                           DECLINED
                                          </td>
                                            :erasmusrequest.status==="EMAILED" ?
                                                <td className={"input"} style={{color:"#00ff3b"}}>
                                                    EMAILED
                                                </td>:
                                                <td>
                                                <ButtonGroup>
                                                    <Button onClick={this.updateRequest.bind(this,erasmusrequest.createdBy,"APPROVED")} size="sm" variant="outline-primary" className={"input"}><span style={{paddingRight:5}} className="normal-icon" data-symbol="&#xf046;" />APPROVE</Button>
                                                    <Button onClick={this.updateRequest.bind(this,erasmusrequest.createdBy,"DECLINED")} size="sm" variant="outline-danger" className={"input"}><span style={{paddingRight:5}} className="normal-icon" data-symbol="&#xf2d4;" />DECLINE</Button>
                                                </ButtonGroup>
                                            </td>

                                    }

                                </tr>
                            ))
                        }

                        </tbody>
                    </Table>

                </Card.Body>
            </Card>
            </div>
        );
    }

}

export default withRouter(RequestsList);