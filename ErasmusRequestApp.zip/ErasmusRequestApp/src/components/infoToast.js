import React, {Component} from "react";
import {Toast} from "react-bootstrap";

export default class InfoToast extends Component{
    render() {
        const toastCss ={
            position:'fixed',
            top:'280px',
            left:'20px',
            width:'250px',
            zIndex:'1',
            boxShadow:'0 4px 8px 0 rgba(0,0,0,0.2), 0 6px 20px 0 rgba(0,0,0,0.19)'
        }
        return (
            <div style={toastCss}>
                <Toast className={"border border-info bg-info text-white"} >
                    <Toast.Header className={"bg-info text-white"} closeButton={false}>
                        <strong className={"mr-auto "}>User Info</strong>
                    </Toast.Header>
                    <Toast.Body className={"input"}>
                        id: {this.props.id}<br/>
                        first name: {this.props.firstName}<br/>
                        surname: {this.props.surname}<br/>
                        birthdate: {this.props.birthdate}<br/>
                        sumgrade: {this.props.sumgrade}<br/>
                        field: {this.props.field}<br/>

                    </Toast.Body>
                </Toast>
            </div>
        );
    };
}