import React from 'react'
function ErrorPage() {
    return (
        <div className="bg-dark App" > <br/><br/><br/><br/><h1 className="input-error text-white" >404</h1>
            <h1 className="input-error" >ERROR</h1>
        </div>
    );
}

export default ErrorPage;