import React from "react";
import { Card, Table} from "react-bootstrap";
import axios from "axios";
import AuthService from '../../services/authService'

class StatusPage extends React.Component{
    constructor(props) {
        super(props);
        this.state={
            requests :[]
        };

    }
    componentDidMount() {
        this.findOwnedRequests();
    }

    findOwnedRequests(){
        axios.get("/request/owned", {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
            .then(response => response.data)
            .then((data)=>{
                this.setState({requests:data});
            });
    }
    render() {
        return (
            <Card className={"border border-dark bg-dark text-light"} style={{marginTop:10,borderRadius:15}}>
                <Card.Header className="login100-form-title text-light">Status Form</Card.Header>
                <Card.Body>
                    <Table bordered hover stripped variant="dark" >
                        <thead>
                        <tr>
                            <th>id</th>
                            <th>Receiver</th>
                            <th>Field</th>
                            <th>Status</th>
                        </tr>
                        </thead>
                        <tbody>

                        {this.state.requests.length === 0 ?
                            <tr>
                                <td colSpan="4">No Requests In the System.</td>
                            </tr> :
                            this.state.requests.map((request)=>(
                                <tr key={request.id}>
                                    <td>{request.id}</td>
                                    <td>{request.sendTo}</td>
                                    <td>{request.field}</td>
                                    {request.status==="null" &&
                                        <td>Pending</td>
                                    }
                                    {request.status==="EMAILED" &&
                                        <td>APPROVED</td>
                                    }
                                    {request.status!=="null" && request.status!=="EMAILED" &&
                                    <td>{request.status}</td>
                                    }
                                </tr>
                            ))
                        }

                        </tbody>
                    </Table>

                </Card.Body>
            </Card>
        );
    }

}

export default StatusPage;