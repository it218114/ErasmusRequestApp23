import React from "react";
import {Form} from "react-bootstrap";
import MyToast from "../myToast";
import MyToastFailure from "../MyToastFailure";
import axios from "axios";
import AuthService from "../../services/authService";

class CreateForm extends React.Component{
    constructor(props){
        super(props);
        this.state={
            firstName:'',
            surname:'',
            birthdate:'',
            sumgrade:'',
            sendTo:'',
            field:'Role',
            errors: { firstName: '', surname:'', birthdate:'', sumgrade:'', sendTo:'', field:'' }
        }

        this.changeFirstNameHandler=this.changeFirstNameHandler.bind(this);
        this.changeSurnameHandler=this.changeSurnameHandler.bind(this);
        this.changeAgeHandler=this.changeAgeHandler.bind(this);
        this.changeSumgradeHandler=this.changeSumgradeHandler.bind(this);
        this.changeSendToHandler=this.changeSendToHandler.bind(this);
        this.changeFieldHandler=this.changeFieldHandler.bind(this);
        this.saveErasmusRequest=this.saveErasmusRequest.bind(this);
        this.state.showSuccess =false;
        this.state.showFailure =false;

    }
    initialState ={
        firstName:'',
        surname:'',
        birthdate:'',
        sendTo:'',
        sumgrade:'',
        field:'Role'
    }
    returnErasmusReuest=()=>{
        return {
            age: this.state.age,
            sumgrade: this.state.sumgrade,
            firstName: this.state.firstName,
            surname: this.state.surname,
            sendTo: this.state.sendTo,
            field: this.state.field
        };
    }

    returnErrors=()=>{
        return { firstName: '', surname:'', age:'', sumgrade:'', sendTo:'', field:'' };
    }


    changeFirstNameHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnErasmusRequest().firstName) {
            this.returnErrors().firstName = 'First Name is required';
        }
        this.setState({firstName:event.target.value});
        this.setState({ errors });
    }

    changeSurnameHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnErasmusRequest().surname) {
            this.returnErrors().surname = 'Surname is required';
        }
        this.setState({surname:event.target.value});
        this.setState({ errors });
    }

    changeAgeHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnErasmusRequest().birthdate) {
            this.returnErrors().birthdate = 'Birthdate is required';
        }
        this.setState({birthdate:event.target.value});
        this.setState({ errors });
    }

    changeSumgradeHandler=(event)=>{
        //this.handleValidation(this.returnErasmusRequest(),this.returnErrors());
        this.setState({sumgrade:event.target.value});

    }


    changeSendToHandler=(event)=>{
        let errors = this.returnErrors();
        if (!this.returnErasmusRequest().sendTo) {
            this.returnErrors().sendTo = 'Receiver it is required';
        }
        this.setState({sendTo:event.target.value});
        this.setState({ errors });

    }

    changeFieldHandler=(event)=>{
        this.setState({field:event.target.value});

    }
    handleValidation = (erasmusrequest,errors) => {

        if (!erasmusrequest.birthdate) {
            errors.birthdate = 'Birthdate is required';
        }

        if (!erasmusrequest.firstName) {
            errors.firstName = 'First Name is required';
        }
        if (!erasmusrequest.surname) {
            errors.surname = 'Surname is required';
        }
        if (!erasmusrequest.sumgrade) {
            errors.sumgrade = 'Sumgrade is required';
        }
        if (!erasmusrequest.sendTo) {
            errors.sendTo = 'Receiver It is required';
        }


        // Rest of validation conditions go here...

        this.setState({ errors });
    }

    saveErasmusRequest=(e)=>{
        e.preventDefault();
        let errors = this.returnErrors();

        this.handleValidation(erasmusrequest,errors);
        if(referral.birthdate&&erasmusrequest.firstName&&erasmusrequest.surname&&erasmusrequest.birthdate&&erasmusrequest.sendTo){
            console.log('ErasmusRequest=>' + JSON.stringify(erasmusrequest));
            axios.post("/request/form",erasmusrequest, {'headers':{'Authorization':AuthService.getCurrentAccessToken()}})
                .then(response =>{
                    if(response.status===406) throw new Error(response.status);
                    else if(response.data!=null){
                        this.setState({"showSuccess":true});
                        this.setState(this.initialState);
                        setTimeout(()=> this.setState({"showSuccess":false}),4000);

                    }else{
                        this.setState({"showSuccess":false});
                    }

                })
                .catch((error)=>{
                    this.setState({"showFailure":true});
                    setTimeout(()=> this.setState({"showFailure":false}),4000);
                });
        }

    }
    render() {
        const { errors } = this.state;
        const {firstName,
            surname,
            birthdate,
            sendTo} = this.state;
        return (
            <div className="outer">
                <div style={{display:this.state.showSuccess ? "block" :"none"}}>
                    <MyToast children={{showSuccess:this.state.showSuccess,messageSuccess:"Erasmus Request Send Successfully!"}}/>
                </div>
                <div style={{display:this.state.showFailure ? "block" :"none"}}>
                    <MyToastFailure children={{showFailure:this.state.showFailure,messageFailure:"Failure to submit!"}}/>
                </div>
                <div className="inner container-fluid bg-dark" style={{background:"#343a40"}}>
                    <div className=' col-md-6 offset-md-3 text-light'>
                        <span className="login100-form-title text-light m-b-23">
						Create a referral
					    </span>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>First Name</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="text" name="firstName" value={firstName} onChange={this.changeFirstNameHandler} placeholder="Type your first name"/>
                            <span className="focus-input100" />
                            {errors.firstName !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.firstName}</span>}
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Surname</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="text" name="surname" value={surname} onChange={this.changeSurnameHandler} placeholder="Type your Surname"/>
                            <span className="focus-input100" />
                            {errors.surname !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.surname}</span>}
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Birthdate</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="number"  min="0"  max="99" name="birthdate" value={birthdate} onChange={this.changeBirthdateHandler} placeholder="Type your birthdate"/>
                            <span className="focus-input100" />
                            {errors.birthdate !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.birthdate}</span>}
                        </div>
                        <div className="  m-b-23" >
                            <span className="label-input100 text-light " style={{display: "block"}} >Sumgrade</span>
                            <div style={{display: "inline-block"}} className="col-md-2 wrap-input100">
                                <input placeholder='1st' value={this.state.sumgrade} onChange={this.changeSumgradeHandler} name='grade' type="number"  min="0"  max="10" step="0.1" className=' input100 text-light'/>
                                <span className="focus-input100" />
                            </div>
                            <div style={{display: "inline-block",marginLeft:20}} className=" col-md-2 wrap-input100">
                                <input placeholder='2nd' value={this.state.grade2} onChange={this.changeGrade2Handler} name='grade2' type="number"  min="0"  max="10" step="0.1" className='input100 text-light'/>
                                <span className="focus-input100" />
                            </div>
                            <div style={{display: "inline-block",marginLeft:20}} className="col-md-2 wrap-input100">
                                <input placeholder='3rd' value={this.state.grade3} onChange={this.changeGrade3Handler} name='grade3' type="number"  min="0"  max="10" step="0.1" className='input100 text-light'/>
                                <span className="focus-input100" />
                            </div>
                            <div style={{display: "inline-block",marginLeft:20}} className=" col-md-2 wrap-input100">
                                <input placeholder='4th'  value={this.state.grade4} onChange={this.changeGrade4Handler} name='grade4' type="number"  min="0"  max="10" step="0.1" className='input100 text-light'/>
                                <span className="focus-input100" />
                            </div>
                        </div>
                        <div className="wrap-input100  m-b-23" >
                            <span className="label-input100 text-light" style={{paddingLeft:0}}>Receiver</span>
                            <input className="input100 text-light" style={{paddingLeft:5}} type="text" name="sendTo" value={sendTo} onChange={this.changeSendToHandler} placeholder="Type your receiver's it"/>
                            <span className="focus-input100" />
                            {errors.sendTo !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.sendTo}</span>}
                        </div>

                        <div  >
                            <span className="label-input100 text-light ">Field</span>
                            <Form.Select onChange={this.changeFieldHandler} defaultValue="Job" className="input100" style={{height:40}}>
                                <option className="input100" value="Job">Job</option>
                                <option className="input100" value="Postgraduate">Postgraduate</option>
                            </Form.Select>
                        </div>


                        <div className="container-login100-form-btn">
                            <div className="wrap-login100-form-btn">
                                <div className="login100-form-bgbtn"/>
                                <button type="submit" onClick={this.saveReferral} className="login100-form-btn">
                                    SUBMIT
                                </button>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        );
    }

}

export default CreateForm;