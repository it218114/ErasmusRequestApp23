import React from 'react';
import {Nav, Navbar} from "react-bootstrap";
import {Link} from "react-router-dom";
import { withRouter } from '../../withRouter.js';
import AuthService from "../../services/authService";

class NavBarStudent extends React.Component {
    constructor(props){
        super(props);
        this.NavForm=this.NavForm.bind(this);
        this.NavStatus=this.NavStatus.bind(this);
        this.NavLogout=this.NavLogout.bind(this);
    }
    NavForm()
    {
        this.props.navigate('/request/form')
    }

    NavStatus()
    {
        this.props.navigate('/request/owned')
    }

    NavLogout(){
        AuthService.logout();
        this.props.navigate('/login')
    }
    render(){
        return (
            <Navbar bg="dark" variant="dark">



                <Navbar.Brand >&emsp;&emsp; ErasmusRequest</Navbar.Brand>
                <Nav >
                    <Nav.Link onClick={this.NavForm}><span className="icon-nav" data-symbol="&#xf298;" />&ensp; Form</Nav.Link>
                    <Nav.Link onClick={this.NavStatus}><span className="icon-nav" data-symbol="&#xf0a2;" />&ensp; Status</Nav.Link>
                    <Nav.Link style={{ position:'fixed',top:'10px', right:'30px'}} onClick={this.NavLogout}>Logout</Nav.Link>
                    <Nav.Link style={{ position:'fixed',top:'6px', right:'130px'}}><span className="icon-nav" data-symbol="&#xf007;"/>&ensp;{AuthService.getCurrentUser().username} </Nav.Link>
                </Nav>


            </Navbar>
        );
    }
}

export default withRouter(NavBarStudent);