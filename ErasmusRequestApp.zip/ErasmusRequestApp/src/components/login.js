import React from "react";
import axios from "axios";
import {connect} from 'react-redux';
import {withRouter} from "../withRouter";
import { setUserSession } from '../utils/utils';
import AuthService from '../services/authService';


class Login extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            username: "",
            password: "",
            loading: false,
            message: "",
            errors: { username: '', password: '' }
        };
    }

    returnUser=()=>{
        return {
            username: this.state.username,
            password: this.state.password,
        };
    }
    handleChange = (e) => {

        this.setState({
            [e.target.name]: e.target.value,
        });
    };
    NavigateAction(){
        if(AuthService.getCurrentUser().roles[0]==="ROLE_ADMIN"){
            this.props.navigate("/admin/users/register");
        }
        if(AuthService.getCurrentUser().roles[0]==="ROLE_TEACHER"){
            this.props.navigate("/requests/sendTo");
        }
        if(AuthService.getCurrentUser().roles[0]==="ROLE_STUDENT"){
            this.props.navigate("/request/form");
        }
    }
    refresh = () => {
        window.location.reload();
    };
    login = (e) => {
        e.preventDefault();
        let user = this.returnUser();
        let errors = { username: '', password: ''};

        if (!user.username) {
            errors.username = 'Username is required';
        }

        if (!user.password) {
            errors.password = 'Password is required';
        }

        // Rest of validation conditions go here...
        this.setState({
            message: "",
            loading: true
        });
        this.setState({ errors });
        if(user.username&&user.password){
            AuthService.login(user.username, user.password).then(
                () => {
                    //console.log(AuthService.getCurrentUser());
                    setTimeout(()=> this.NavigateAction(),0);
                    setTimeout(()=> this.refresh(),0);
                },
                error => {
                    const resMessage =
                        (error.response &&
                            error.response.data &&
                            error.response.data.message) ||
                        error.message ||
                        error.toString();

                    this.setState({
                        loading: false,
                        message: resMessage
                    });
                }
            );
        } else {
            this.setState({
                loading: false
            });
        }



    };
    render() {
        const { errors } = this.state;
        return (

            <div className="outer login">

                <div className="inner">
                    <form>
                <span className="login100-form-title p-b-49">
						ErasmusRequest
					</span>


                        <div className="wrap-input100 validate-input m-b-23" data-validate="Username is required">
                            <span className="label-input100">Username</span>

                            <input value={this.state.username} onChange={this.handleChange} autoComplete={"off"} className="input100" type="text" name="username" placeholder="Type your username"/>
                            <span className="focus-input100" data-symbol="&#xf007;"/>
                            {errors.username !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.username}</span>}
                        </div>

                        <div className="wrap-input100 validate-input" data-validate="Password is required">
                            <span className="label-input100">Password</span>
                            <input value={this.state.password} onChange={this.handleChange} className="input100" type="password" name="password" placeholder="Type your password"/>
                            {errors.password !== '' && <span className="error-nav" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.errors.password}</span>}
                            <span className="focus-input100" data-symbol="&#xf023;"/>
                        </div>

                        {this.state.message && <span className="error-nav input" data-symbol="&#xf05a;" style={{color: "red"}}>{this.state.message}</span>}
                        <div className="container-login100-form-btn">
                            <div className="wrap-login100-form-btn">
                                <div className="login100-form-bgbtn"/>
                                <button type="button" className="login100-form-btn" onClick={this.login}>
                                    Login
                                </button>
                            </div>
                        </div>

                    </form>
                </div>


            </div>



        );
    }





}

export default (withRouter(Login));