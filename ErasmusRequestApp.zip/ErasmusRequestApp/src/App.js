import React, {useEffect, useState} from 'react';
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';
import './App.css';

import Login from "./components/login";
import {BrowserRouter, Router, Routers, Route, Routes, Navigate, Link} from "react-router-dom";
import NavigationBar from "./components/admin/NavigationBar.js"
import NavBarStudent from "./components/student/NavBarStudent.js"
import NavBarTeacher from "./components/teacher/NavBarTeacher.js"
import Footer from "./components/Footer";
import UserList from "./components/admin/UserList";
import RequestsList from "./components/teacher/RequestsList";
import StatusPage from "./components/student/StatusPage";
import CreateForm from "./components/student/CreateForm";
import AddThirdParty from "./components/admin/AddThirdParty";
import EmailPage from "./components/teacher/EmailPage";
import RegisterPage from "./components/admin/RegisterPage"
import ErrorPage from "./components/ErrorPage"
import {Container,Row, Col} from "react-bootstrap";

import EventBus from "./common/EventBus";
import AuthService from "./services/authService";

class App extends React.Component {
    constructor(props) {
        super(props);


        this.state = {
            showTeacherBoard: false,
            showAdminBoard: false,
            showStudentBoard:false,
            currentUser: undefined,
        };
    }


    componentDidMount() {
        const user = AuthService.getCurrentUser();

        if (user) {
            this.setState({
                currentUser: user,
                showTeacherBoard: user.roles.includes("ROLE_TEACHER"),
                showAdminBoard: user.roles.includes("ROLE_ADMIN"),
                showStudentBoard: user.roles.includes("ROLE_STUDENT")
            });
        }


    }





    render(){
        const { currentUser, showTeacherBoard, showAdminBoard, showStudentBoard } = this.state;
        return (

            <div className="App">

                <Routes>
                    <Route path="/" element={<Navigate to="/login" />}
                    />
                    <Route exact path="/login" element={<Login/>} />
                    {showAdminBoard &&
                    <Route exact path="/admin/users/register" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavigationBar/>

                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <RegisterPage/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showAdminBoard &&
                    <Route exact path="/admin/users/modify" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavigationBar/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <UserList/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showAdminBoard &&
                    <Route exact path="/admin/users/modify/:it" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavigationBar/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <RegisterPage/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showAdminBoard &&
                    <Route exact path="/admin/thirdparty/add" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavigationBar/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <AddThirdParty/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showStudentBoard &&
                    <Route exact path="/request/form" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavBarStudent/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <CreateForm/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showStudentBoard &&
                    <Route exact path="/request/owned" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavBarStudent/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <StatusPage/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    {showTeacherBoard &&
                    <Route exact path="/requests/sendto/" element={
                        <>
                            <div className="App" style={{backgroundColor:"#272B30"}}>
                                <NavBarTeacher/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop:20}}>
                                            <RequestsList/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    } />}
                    {showTeacherBoard &&
                    <Route exact path="/requests/approved/:it" element={
                        <>
                            <div className="App" style={{backgroundColor: "#272B30"}}>
                                <NavBarTeacher/>
                                <Container>
                                    <Row>
                                        <Col lg={12} style={{marginTop: 20}}>
                                            <EmailPage/>

                                        </Col>
                                    </Row>
                                </Container>
                                <Footer/>
                            </div>
                        </>
                    }/>
                    }
                    <Route path="*" element={<ErrorPage />}/>

                </Routes>

            </div>

        );
    }

}

export default App;